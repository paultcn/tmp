#ifndef AVAS_AVAS_SERVER_H_
#define AVAS_AVAS_SERVER_H_


#include <mqueue.h>
#include <pssClient.h>
#include <vehicle_service/type.h>
#include <vehicle_service/vehicleClient.h>
#include "avas_sine_lib.h"

#include "slog.h"
#include "chime_file.h"
#include <common_base/cJSON/cJSON.h>
#include <common_base/fdbus.h>
#include <common_base/CFdbProtoMsgBuilder.h>
#include <proto/com.gwm.base.avas.ctrl.pb.h>
#include "debug.h"


#undef ENABLE_QMON

#define FDB_LOG_TAG "FDB_AVAS_SERVER"

#define MAX_AVAS_VALID_SPEED (35)
#define AVAS_GENDATA_BUFFSIZE (1536)

// file playback options.
//#define FILE_CONTINUOUS_MODE_ENABLED      (0x01)
//#define FILE_CONTINUOUS_MODE_DISABLED     (0x00)

/* fdbus server path */
#define FDB_PSS_SERVERNAME     "fdbus_psservice_qnx"
#define PSS_SERVICE_URL        "svc://fdbus_psservice_qnx"

#define DEFAULT_AVAS_FILE       "/cluster/usr/etc/AvasAudio/avas1.wav"

enum AVAS_DATA_ID {
  AVAS_DATA_PING = 0,
  AVAS_DATA_PONG = 1
};

// queue message struct
typedef struct {
	AvasServer::AVAS_MODE avas_mode;
	int32_t speed;                        // vehicle speed.
	int32_t speedValid;                 // vehicle speed valid.
	int32_t gear;                       // gear type.
} MQ_MSG;


#define PRINT_TIMESTAMP(flag)  { \
struct timespec ts; \
if( clock_gettime( CLOCK_MONOTONIC, &ts) == -1 ) \
{\
	perror( "getclock" );\
}\
if ( DebugLevel >= 4 ) printf("%s - %s :%ld sec, %ld nsec\n",__func__, (flag), ts.tv_sec,ts.tv_nsec);\
}
//wav file size
extern uint32_t s_bufLen = 0;
//wav file buffer
extern char* s_buf = NULL;

extern int g_channels;
extern int g_block_align;
extern volatile int sig_exit;
extern mqd_t g_mqMsgQ;
extern mqd_t g_mqAvasQ;
extern void vehicleClientRegisterSignal(std::vector<int32_t>& subscribe_propId);
extern bool external_sound_init(ChimeFileBuffer *chimeFileBuffer);
extern void external_sound_destroy();
extern void external_sound_play();
extern void external_sound_stop();
extern void* avas_gendata(void * args);
extern void external_sound_play_bosch_example();
extern bool chimefile_init(char *wav_filename);
extern int ioaudio_sound_init(char *soundDevName, ChimeFileBuffer *chimeFileBuffer);
extern int writeData(int nframes, void *arg, int size);
extern void ioaudio_sound_play();

#endif /* AVAS_AVAS_SERVER_H_ */

