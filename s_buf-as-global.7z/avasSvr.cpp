#include <assert.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <gulliver.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/termio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <atomic.h>
#include <math.h>

#include <sys/asoundlib.h>
#include <sys/neutrino.h>
#include <sys/procmgr.h>


#include <vector>
#include <string>

#include <string>
#include <vector>
#include "avasSvr.h"

#define PSS_AVAS_KEY "avas_mode"
#define FDB_AVAS_FILTER "avas_filter"
/*
 * Globals
 */
volatile int sig_exit;
unsigned DebugLevel;
char g_mqName[_POSIX_PATH_MAX] = { 0 };
char g_mqAvasName[_POSIX_PATH_MAX] = { 0 };
mqd_t g_mqMsgQ;
mqd_t g_mqAvasQ;

bool g_UseExtAudioClient = false;
char g_AudioDevName[_POSIX_PATH_MAX] = { 0 };
AvasServer::AVAS_MODE genu_AVAS_MODE = AvasServer::MODE_1;
//声道数
int g_channels = 1;
int g_block_align = g_channels*2;
//wav file size
uint32_t s_bufLen = 0;
//wav file buffer
char* s_buf = NULL;

/*
 * Locals
 */
static cJSON *cjson_config;
static volatile int num_sinks;
static int playback_priority = 10;
static int32_t tmp_speed = 0;
static int32_t tmp_speedValid = 0;
static int32_t tmp_gear = 0;
static float ReverseSineGain = 0.5;
static char config_file[_POSIX_PATH_MAX] = { 0 };

static MQ_MSG mqMsg;
static ChimeFileBuffer chimeFileBuffer;

/* At this point our process goes live and has one thread, the
 * main thread. All setup for this was done by the OS.
 */
static CBaseWorker main_worker;
static CBaseWorker background_worker;
static PSSClient *g_pPssClient = NULL;
static FdbSessionId_t g_fdbSid = FDB_INVALID_ID;
class CAvasServer;

using namespace bosch::platform::vehicle;

//*****************************************************************************
/* *INDENT-OFF* */
#ifdef __USAGE
%C [Options]

Version: 0.0.1
-c [config file]
-v verbosity (can be issued multiple times)
-a [play back out device name]

Examples:
Use /etc/avas/avas.conf and choose extAudioClient to play back:
	avasSvr -c /etc/avas/avas.conf
Use /etc/avas/avas.conf and directly use io-audio to play back:
	avasSvr -c /etc/avas/avas.conf -a /dev/snd/pcmC0D0p
With verbosity logs:
    avasSvr -vvvvvv -c /etc/avas/avas.conf -a /dev/snd/pcmC0D0p

#endif
/* *INDENT-ON* */
//*****************************************************************************
static char* AVAS_WAV_FILENAMES[] = 
{
	"/cluster/usr/etc/AvasAudio/avas1.wav",
	"/cluster/usr/etc/AvasAudio/avas2.wav",
	"/cluster/usr/etc/AvasAudio/avas3.wav"
};


static AVAS_CFG_TBL_t tConfigAvas =
		{ 160,	// 对应车速0的频率
				64,		// numberOfSample
				// AVAS Sine 0km/h - 30km/h 包络曲线
				{ 0.0f, 0.04f, 0.04f, 0.04f, 0.04f, 0.04f, 0.04f, 0.04f, 0.04f,
						0.04f, 0.04f, 0.04f, 0.04f, 0.04f, 0.04f, 0.04f, 0.04f,
						0.04f, 0.04f, 0.04f, 0.035f, 0.03f, 0.025f, 0.02f,
						0.015f, 0.01f, 0.005f, 0.0f, 0.0f, 0.0f, 0.0f },
				// wav音频 0km/h - 30km/h 包络曲线
				{ 0.0f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f,
						0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f,
						0.5f, 0.4f, 0.35f, 0.3f, 0.2f, 0.15f, 0.1f, 0.06f,
						0.04f, 0.02f, 0.0f, 0.0f } };



void die(const char* fmt, ...) {
	va_list argList;

	va_start(argList, fmt);
	vfprintf(stderr, fmt, argList);
	va_end(argList);

	//TODO: shutdown something.
	if (g_UseExtAudioClient) {
		external_sound_destroy();
	}

	exit(-1);
}

void signal_handler(int signal) {
	char *config;

	if (signal == SIGHUP) {
		config = cJSON_Print(cjson_config);
		SLOG_I("%s\n", config);
		free(config);
	} else {
		SLOG_E("Caught signal to exit (%d)!\n", signal);
		sig_exit = 1;
		background_worker.exit();
		main_worker.exit();
	}
	printf("Caught signal (%d)!\n", signal);
}



/*
 * read_config - reads in JSON config file
 */
int read_config(char *config_file, cJSON **json_config) {
	size_t len;
	char *data;
	FILE *f;

	/* Determine the size of the file */
	f = fopen(config_file, "rb");
	if (f == NULL) {
		return (-1);
	}
	fseek(f, 0, SEEK_END);
	len = ftell(f);

	/* Read in the config file */
	fseek(f, 0, SEEK_SET);
	data = (char *) malloc(len + 1);
	if (data == NULL) {
		fclose(f);
		return (-2);
	}
	fread(data, 1, len, f);
	fclose(f);

	/* Parse the settings */
	*json_config = cJSON_Parse(data);
	free(data);

	if (*json_config == NULL) {
		return (-3);
	}

	return (0);
}


void vehclieCallback(VehiclePropValue prop_value, PropertyType prop_type) {

	switch (prop_type) {
	case PROPERTY_TYPE_BOOL: {
		//bool val = prop_value.value.int32Values[0];
	}
		break;
	case PROPERTY_TYPE_INT32: {
		std::vector<int32_t> val = prop_value.value.int32Values;
		// 1. gear
		/*if (prop_value.prop == toInt(VehicleProperty::DCT5_TGS_LEVER)) {
			if (val.size() > 0) {
				SLOG_I("gear is %d. \n", val[0]); //0:P,5:D,6:N,7:R,8:M
				tmp_gear = val[0];
			}
		}
		*/
		if(prop_value.prop == toInt(VehicleProperty::HCU_HP6_HCU_GEARSTS))
		{
			if(val.size()>0)
			{
				SLOG_I("gear is %d. \n",val[0]);  //0:P,5:D,6:N,7:R
				tmp_gear = val[0];
			}
		}
		 
		//2. speed
		if (prop_value.prop == toInt(VehicleProperty::ESP_FD2_VEHSPDVLD)) {
			if (val.size() > 0) {
				SLOG_I("speed valid is %d. \n", val[0]); //0 " Invalid values " 1 " Valid values "
				tmp_speedValid = val[0];
			}
		}
		// do something
	}
		break;
	case PROPERTY_TYPE_INT64: {
		std::vector<int64_t> val = prop_value.value.int64Values;
		// do something
	}
		break;
	case PROPERTY_TYPE_FLOAT: {
		std::vector<float> val = prop_value.value.floatValues;
		// 1. speed
		if (prop_value.prop == toInt(VehicleProperty::ESP_FD2_VEHSPD)) {
			if (val.size() > 0) {
				tmp_speed = (int32_t)round(val[0]);
				//printf("speed is %f. \n", tmp_speed);
			}
		}
		// do something
	}
		break;
	case PROPERTY_TYPE_STRING: {
		std::string val = prop_value.value.stringValue;

		// do something
	}
		break;
	case PROPERTY_TYPE_BYTE: {
		std::vector<uint8_t> val = prop_value.value.bytes;
		// do something
	}
		break;
	default:

		break;
	}

	//  Filter invalid speed
	if ( tmp_speedValid && tmp_speed <= MAX_AVAS_VALID_SPEED )
	{
	    mqMsg.avas_mode = genu_AVAS_MODE;
		mqMsg.gear = tmp_gear;
		mqMsg.speed = tmp_speed;
		mqMsg.speedValid = tmp_speedValid;
	    mq_send(g_mqMsgQ, (char *) &mqMsg, sizeof(mqMsg), 0);
		debug_info(("mqMsg sent mode:%d, gear:%d, speed:%d, speedValid:%d\n", 
			mqMsg.avas_mode,mqMsg.gear,mqMsg.speed,mqMsg.speedValid));
	}
}

void vehclieErrorCallback(int propId, VehiclePropertyStatus status) {
	if (toInt(VehicleProperty::ESP_FD2_VEHSPD) == propId
			&& VehiclePropertyStatus::ERROR == status) {
		// Signal ACDualModEnaSts timeout or lost, you can do some process here
	}
}
/* Parse avas.conf if pass in, call avas lib init function to initialize avas */
void initAvas(void)
{
	int err;
	char *config_debug;
	cJSON *SpeedToSinGainArray;
	cJSON *SpeedToWavGainArray;
	int i;
		
    if ( config_file[0] != '\0')
	{
		/* Gobble up our config file */
		if ((err = read_config(config_file, &cjson_config)) < 0) {
			die("Problem parsing JSON configuration file (%d)!\n", err);
		}

		/* Regurgitate our config if debug is high enough */
		if (DebugLevel >= 4) {
			config_debug = cJSON_Print(cjson_config);
			SLOG_I("%s\n", config_debug);
			free(config_debug);
		}

		/* parse config and setting to tConfigAvas global param */
		tConfigAvas.StartFreq = cJSON_GetObjectItem(cjson_config, "StartFreq")->valueint;
		tConfigAvas.numberOfSample = cJSON_GetObjectItem(cjson_config, "numberOfSample")->valueint;
		ReverseSineGain = cJSON_GetObjectItem(cjson_config, "ReverseSineGain")->valuedouble;

		SpeedToSinGainArray = cJSON_GetObjectItem(cjson_config, "SpeedToSinGain");
		if ((SpeedToSinGainArray == NULL) || (SpeedToSinGainArray->type != cJSON_Array)) {
			die("Corrupt or missing \"SpeedToSinGain\" array in config file.\n");
		}
		/* Iterate over array */
		for (i = 0; i < cJSON_GetArraySize(SpeedToSinGainArray); i++) {
			tConfigAvas.SpeedToSinGain[i] = cJSON_GetArrayItem(SpeedToSinGainArray, i)->valuedouble;
		}

		SpeedToWavGainArray = cJSON_GetObjectItem(cjson_config, "SpeedToWavGain");
		if ((SpeedToWavGainArray == NULL) || (SpeedToWavGainArray->type != cJSON_Array)) {
			die("Corrupt or missing \"SpeedToWavGain\" array in config file.\n");
		}
		/* Iterate over array */
		for (i = 0; i < cJSON_GetArraySize(SpeedToWavGainArray); i++) {
			tConfigAvas.SpeedToWavGain[i] = cJSON_GetArrayItem(SpeedToWavGainArray, i)->valuedouble;
		}
		
		/* Regurgitate our tConfigAvas if debug is high enough */
		if (DebugLevel >= 4) {
			SLOG_I("tConfigAvas.StartFreq: %d\n", tConfigAvas.StartFreq);
			SLOG_I("tConfigAvas.numberOfSample: %d\n", tConfigAvas.numberOfSample);
			SLOG_I("ReverseSineGain: %.3f\n", ReverseSineGain);

			SLOG_I("tConfigAvas.SpeedToSinGain[]: ");
			for (i = 0; i < (int)(sizeof(tConfigAvas.SpeedToSinGain)/sizeof(tConfigAvas.SpeedToSinGain[0])); i++ ){
				SLOG_I("%.3f, ", tConfigAvas.SpeedToSinGain[i]);
			}
			SLOG_I("\n");
			
			SLOG_I("tConfigAvas.SpeedToWavGain[]: ");
			for (i = 0; i < (int)(sizeof(tConfigAvas.SpeedToWavGain)/sizeof(tConfigAvas.SpeedToWavGain[0])); i++ ){
				SLOG_I("%.3f, ", tConfigAvas.SpeedToWavGain[i]);
			}
			SLOG_I("\n");
		}
		
    }
	/* Initialize the avas lib */
	if (AvasLib_init(&tConfigAvas) == false) {
		die("AVAS initial failed!!!\n");
	}
	AvasLib_SetWorkState(AVAS_ON);


}

/* a timer broadcasting now-playing information periodically */
class CBroadcastTimer : public CMethodLoopTimer<CAvasServer> 
{
public:
    CBroadcastTimer(CAvasServer *server);
};

/* demo code for Avas server; inherit from CBaseServer */
class CAvasServer : public CBaseServer
{
public:
    CAvasServer(const char *name, CBaseWorker *worker = 0)
        : CBaseServer(name, worker)
    {
        mTimer = new CBroadcastTimer(this);
        /*
         * attach the timer to worker to run the timer callback at the thread
         * 'false' means don't start the timer
         */
        mTimer->attach(&main_worker, false);
    }
	
    /* callback called by the timer to broad elapse time.*/
    void broadcastElapseTime(CMethodLoopTimer<CAvasServer> *timer)
    {
        
    }
protected:
    void onOnline(FdbSessionId_t sid, bool is_first)
    {
        SLOG_I("server session up: %d\n", sid);
        if (is_first)
        {
            /* enable broadcast timer when the first client is connected */
            SLOG_I("timer enabled\n");
            mTimer->enable();
        }
    }
    void onOffline(FdbSessionId_t sid, bool is_last)
    {
        SLOG_I("server session shutdown: %d\n", sid);
        if (is_last)
        {
            /* disable broadcast timer when the last client is disconnected */
            mTimer->disable();
        }
    }
    /* called when client calls invoke() */
    void onInvoke(CBaseJob::Ptr &msg_ref)
    {
        auto msg = castToMessage<CBaseMessage *>(msg_ref);

        static int32_t elapse_time = 0;
        switch (msg->code())
        {
        case AvasServer::MSG_AVAS_GET_MODE:
			{
			    //std::string str_filter(filter);
			    //if (!str_filter.compare("my_filter"))
			    {
					/* fill up protocol buffer */
					AvasServer::AvasCtrlMode ctlMode;
					ctlMode.set_mode(genu_AVAS_MODE);
					
					/* broadcast elapse time; "my_filter" have no mean but test */
					CFdbProtoMsgBuilder builder(ctlMode);
					//broadcast(AvasServer::EVT_AVAS_STATUS, builder, FDB_AVAS_FILTER);
					msg->reply(msg_ref, builder);
			    }
			}			
		    break;
		case AvasServer::MSG_AVAS_SET_MODE:
			{
			    /*
				 * recover protocol buffer from incoming package
				 * it should match the type sent from client
				 */
				AvasServer::AvasCtrlMode ctlMode;
				CFdbProtoMsgParser parser(ctlMode);
				if (!msg->deserialize(parser))
				{
					//msg->status(msg_ref, FDB_ST_MSG_DECODE_FAIL, "Fail to decode request!");
					SLOG_E("Fail to decode request!");
					return;
				}
				FDB_LOG_I("set avas mode as: %d, sender: %s\n", ctlMode.mode(), msg->senderName().c_str());
				if (  ctlMode.mode() != genu_AVAS_MODE )
				{
					genu_AVAS_MODE = ctlMode.mode();
				    if (genu_AVAS_MODE != AvasServer::MODE_OFF )
				   	{
					    g_pPssClient->setIntValue(PSS_AVAS_KEY, genu_AVAS_MODE);
						if (g_UseExtAudioClient)
						{
							external_sound_stop();
							delay(5);
							chimefile_init(AVAS_WAV_FILENAMES[genu_AVAS_MODE]);
							external_sound_init(&chimeFileBuffer);
							delay(5);
							external_sound_play();
						}
						else
						{
						    //TODO: restart ioaudio play.
						}
				   	}
				    else
				   	{
						if (g_UseExtAudioClient)
						{
							external_sound_stop();
						}
						else
						{
							//TODO: stop ioaudio.
						}
				   	}
				}
				/* fill in protocol buffer and reply to client */
				{
					AvasServer::AvasCtrlMode ctlMode;
					ctlMode.set_mode(genu_AVAS_MODE);
					CFdbProtoMsgBuilder builder(ctlMode);
					msg->reply(msg_ref, builder);
				}
			}
			break;
		default:
			{
			    FDB_LOG_I("unknown invoke: %d, sender: %s\n", msg->code(), msg->senderName().c_str());
			}
			break;            
        }
    }
    /* called when client call subscribe() to register message */
    void onSubscribe(CBaseJob::Ptr &msg_ref)
    {
        auto msg = castToMessage<CFdbMessage *>(msg_ref);
        const CFdbMsgSubscribeItem *sub_item;
        /* iterate all message id subscribed */
        FDB_BEGIN_FOREACH_SIGNAL(msg, sub_item)
        {
            FdbMsgCode_t msg_code = sub_item->msg_code();
            const char *filter = "";
            if (sub_item->has_filter())
            {
                filter = sub_item->filter().c_str();
            }
            FdbSessionId_t sid = msg->session();

            /* reply initial value to the client subscribing the message id */
            switch (msg_code)
            {
                case AvasServer::EVT_AVAS_STATUS:
                {
                    std::string str_filter(filter);
                    //if (!str_filter.compare("my_filter"))
                    {
						/* fill up protocol buffer */
						AvasServer::AvasCtrlMode ctlMode;
						ctlMode.set_mode(genu_AVAS_MODE);
						
						/* broadcast elapse time; "my_filter" have no mean but test */
						CFdbProtoMsgBuilder builder(ctlMode);
						broadcast(AvasServer::EVT_AVAS_STATUS, builder, FDB_AVAS_FILTER);
                    }
                }
                default:
                break;
            }
        }
        FDB_END_FOREACH_SIGNAL()
    }

private:
    CBroadcastTimer *mTimer;
};

/* create a timer: interval is 1500ms; cyclically; when timeout, call CAvasServer::broadcastElapseTime */
CBroadcastTimer::CBroadcastTimer(CAvasServer *server)
    : CMethodLoopTimer<CAvasServer>(1500, true, server, &CAvasServer::broadcastElapseTime)
{}

std::vector<std::string> split(std::string str, std::string pattern)
{
    std::string::size_type pos;
    std::vector<std::string> result;
    str += pattern;//扩展字符串以方便操作
    int size = str.size();
    for (int i = 0; i < size; i++)
    {
        pos = str.find(pattern, i);
        if (pos < size)
        {
            std::string s = str.substr(i, pos - i);
            result.push_back(s);
            i = pos + pattern.size() - 1;
        }
    }
    return result;
}

bool chimefile_init(char *wav_filename)
{
    int rc = -1;
	char *pData = NULL;
	uint32_t data_len = 0;
	

	if( NULL == wav_filename )
	{
		die(("The wav_filename can't been NULL !!!\n"));
		//return false;
	}
	
    memset(&(chimeFileBuffer.file_info), 0, sizeof(ChimeFileInfo));
	strncpy(chimeFileBuffer.file_info.filename,wav_filename,FILE_NAME_SIZE);
	
	rc= read_file_to_buffer(&(chimeFileBuffer));
	if (rc == NO_ERROR){
		pData = (char *)chimeFileBuffer.wav_data_buffer;
		data_len = chimeFileBuffer.file_info.data_size_total;
		debug_info(("chime file pData =0X%p data_len = %d\n", pData, data_len));
	
		s_buf = (char *)chimeFileBuffer->wav_data_buffer;
		s_bufLen = chimeFileBuffer->file_info.data_size_total;
	
	}
	else
	{
	    die("Chime file read failed!!!\n");
	    //return false;
	}
    return true;
}

int main(int argc, char **argv) {
	int c;
	int wavFileIndex = 0;
	pthread_t th_avas_gendata;
    mq_attr attrAvasQ;
	
	DebugLevel = 0;
	sig_exit = 0;

	/* Gobble up our options */
	while ((c = getopt(argc, argv, "Vvc:a:p:")) != EOF) {
		switch (c) {
		case 'V':
		case 'v':
			DebugLevel++;
			break;
		case 'a':
            if (strchr (optarg, ':'))
            {
                //card = atoi (optarg);
                //dev = atoi (strchr (optarg, ':') + 1);
                die("Unsupported for card:dev mode!");
            }
            else if (isalpha (optarg[0]) || optarg[0] == '/')
            {
                strcpy (g_AudioDevName, optarg);
            }
            else
			{
				//dev = atoi (optarg);
				die("Unsupported for card:dev mode!");
			}
            if (g_AudioDevName[0] != '\0')
                printf ("Using device %s\n", g_AudioDevName);
            //else
            //    printf ("Using card %d device %d \n", card, dev);
			break;
		case 'c':
			strcpy(config_file, optarg);
			debug(3, ("Config file: %s\n", config_file));
			break;
		case 'p':
			playback_priority = atoi(optarg);
			break;
		default:
			return 1;
		}
	}

	/* Install signal handlers prior to read/write thread creation */
	signal( SIGINT, signal_handler);
	signal( SIGHUP, signal_handler);
	signal( SIGTERM, signal_handler);

	FDB_CONTEXT->start();
	CBaseWorker *worker_ptr = &main_worker;
	worker_ptr->start();

	// init pss client
	std::string pss_server_name = FDB_PSS_SERVERNAME;
	std::string url_pssClient(PSS_SERVICE_URL);
	g_pPssClient = new PSSClient(pss_server_name.c_str(), worker_ptr);
	g_pPssClient->enableReconnect(true);
	g_fdbSid = g_pPssClient->connect(url_pssClient.c_str());

	
	// init queues
	sprintf(g_mqName, "/avas_%d_MQ", getpid());
	g_mqMsgQ = mq_open(g_mqName, O_CREAT | O_RDWR | O_NONBLOCK/**/, 777, NULL);
	if (g_mqMsgQ == -1) {
		die("Failed to create mq object");
	}
	
    attrAvasQ.mq_maxmsg = 1024; /* 設定訊息佇列的最大訊息個數 */
    attrAvasQ.mq_msgsize = 1800; /* 設定每個訊息的最大位元組數 */	
	sprintf(g_mqAvasName, "/avas_gendata_%d_MQ", getpid());
	g_mqAvasQ = mq_open(g_mqAvasName, O_CREAT | O_RDWR | O_NONBLOCK, 777, &attrAvasQ);
	if (g_mqAvasQ == -1) {
		die("Failed to create avas mq object");
	}

	initAvas();

	// TODO: get AVAS settings from pss.
	/* wait for pss connected */
	sleep(1);
	if (g_pPssClient->isOnLine()) {
		SLOG_I("pss connect success.\n");
		genu_AVAS_MODE = (AvasServer::AVAS_MODE)g_pPssClient->getIntValue(PSS_AVAS_KEY);
		if (genu_AVAS_MODE == AvasServer::MODE_OFF)
		{
			g_pPssClient->setIntValue(PSS_AVAS_KEY, AvasServer::MODE_1);
			genu_AVAS_MODE =  AvasServer::MODE_1;
		}
		SLOG_I("get AVAS_MODE int value:%d \n", genu_AVAS_MODE);
	} else {
		debug_info(("pss not connect success.\n"));
	}

	// prepare wav file to play
	wavFileIndex = (genu_AVAS_MODE == 0) ? genu_AVAS_MODE : (genu_AVAS_MODE-1);
	chimefile_init(AVAS_WAV_FILENAMES[wavFileIndex]);
	
    if (g_AudioDevName[0] != '\0')
    {
        // TODO:
        // directly use io-audio to play wave, use play back out dev name to io-audio.
		g_UseExtAudioClient = false;
		//die("Unsupported for directly io-audio play!");
		ioaudio_sound_init(g_AudioDevName, &chimeFileBuffer);
    }
	else
	{
		g_UseExtAudioClient = true;
		external_sound_init(&chimeFileBuffer);
	}

	// init vehicle client
	std::vector<int32_t> subscribe_propId;
	VehicleClient *vehicleclient = VehicleClient::getInstance();
	
	// for test purpose, if priority opt is 0, we use bosch origin example to play origin wav file.
	if ( playback_priority != 0 )
	{
	    /* create servers and bind the address: svc://service_name */
		std::string server_name = "fdbus_avas";
		std::string url(FDB_URL_SVC);
		server_name += "_service";
		url += server_name;
		auto server = new CAvasServer(server_name.c_str(), worker_ptr);
		server->bind(url.c_str());

		// regist vehicle signal
		vehicleClientRegisterSignal(subscribe_propId);
		vehicleclient->subscribe(vehclieCallback, subscribe_propId,
				vehclieErrorCallback);
		
		// init avas gen data thread	
		pthread_create(&th_avas_gendata, NULL, &avas_gendata, NULL);

	    // prepared for play wav
		if (g_UseExtAudioClient) {
			external_sound_play();
		}
		else
		{
			ioaudio_sound_play();
		}
	}
	else
	{
	    // call bosch original example code to verify wav playing.
		external_sound_play_bosch_example();
	}

	if (procmgr_daemon(EXIT_SUCCESS, PROCMGR_DAEMON_NOCLOSE
				|PROCMGR_DAEMON_NODEVNULL ) == -1)
	{
		printf("failed to going background\n");
		return -1;
	}

    /* convert main thread into worker */
    CBaseWorker *bgworker_ptr = &background_worker;
    bgworker_ptr->start(FDB_WORKER_EXE_IN_PLACE);

    /* do clean up */
	cJSON_Delete(cjson_config);
	
	vehicleclient->unsubscribe(vehclieCallback, subscribe_propId);
	
	g_pPssClient->disconnect(g_fdbSid);
	delete g_pPssClient;
	
	mq_unlink (g_mqName);
	mq_unlink (g_mqAvasName);
	if (g_UseExtAudioClient) {
		external_sound_stop();
		external_sound_destroy();
	}
	uninitialize_file(&(chimeFileBuffer.file_info));

	return EXIT_SUCCESS;
}

