/*
================================================================================
@file    ExternalAudioManagerTest.cpp
@brief   external audio manager function test
================================================================================
*/

#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/pathmgr.h>
#include <string>
#include <mqueue.h>

/*
#include <iostream>
#include <ctime>
#include <ratio>
#include <chrono>
using namespace std::chrono;
*/
#include <time.h>
#include <pthread.h>
#include "ping-pong.h"
#include "externalSound.h"
#include "chime_file.h"
#include "avasSvr.h"

#define TEST_AVAS_FILE       "/logdata/wav_data/Chime04.wav"
#define TEST_POWEROFF_FILE   "/logdata/wav_data/boot.wav"
#define TEST_CHARGING_FILE   "/logdata/wav_data/Chime05.wav"

typedef struct
{
    const std::string param_str[30];
    const std::string help_str[30];
    int len;
}parameter_t;
typedef struct
{
    bool avasgendone;
    uint avasfmposition;
    char avasfmdata[AVAS_GENDATA_BUFFSIZE];
}AVAS_FMDATA_t;

static  parameter_t par_str[]={
        {
            {"play_type","pData","data_len","play_count","interval"},
            {"play_type:\n"
                  "1-external_sound_type_avas\n"
                  "2-external_sound_type_shutdown\n"
                  "3-external_sound_type_charge\n"
                  "others-invalid param\n",
              "pData:pointer to wav data buffer,can't set by test app",
              "data_len:the wav data buffer size,can't set by test app",
              "play_count:how many times this file will be play,0 means infinity",
              "interval:the time between current play finish and next time play start",
            },
            5
        },
        {
            {"play_type","stop_tyle"},
            {"play_type:\n"
                  "1-external_sound_type_avas\n"
                  "2-external_sound_type_shutdown\n"
                  "3-external_sound_type_charge\n"
                  "others-invalid param\n",
             "stop_tyle:\n"
                 "1-external_sound_stop_type_immediately\n"
                 "2-external_sound_stop_type_previous\n"
                 "others-invalid param\n",
            },
            2
        }
};


static int playState = 0;

static uint32_t s_bufIdx = 0;
//avas gendata buffer
static char s_avasFmDataBuff[AVAS_GENDATA_BUFFSIZE] = {0};
static char* s_avasDataLastBackup = s_avasFmDataBuff;
static AVAS_FMDATA_t s_msgAvasFmData = {0};



 	
void* avas_gendata(void * args)
{
	MQ_MSG msg;
	struct mq_attr mqstat;
    int msg_size;
	
	char *buffer = NULL;
	
	static AvasServer::AVAS_MODE s_cur_avas_mode = AvasServer::MODE_OFF;
	static int32_t s_cur_speed = 0;                        // vehicle speed.
	//static int32_t s_cur_speedValid = 0;                 // vehicle speed valid.
	static int32_t s_cur_gear = 0;                       // gear type.

    AVAS_CTL_PARAM param;
	AVAS_CTL_STATE state;
	uint32_t numberofsample = AvasLib_GetnumberOfSample();
	
    char* outdata = NULL;

	buffer = (char *)malloc(numberofsample*sizeof(int32_t));
	if ( buffer == NULL )
		return(NULL);
	
	// qnx message queue attributes
	mq_getattr(g_mqMsgQ, &mqstat);
	while ( !sig_exit )
	{
		memset(&msg, 0, sizeof(MQ_MSG));
		msg_size = mq_receive(g_mqMsgQ, (char *) &msg, (long) &mqstat.mq_msgsize,NULL);
		// check for error
		if (msg_size == -1) {
			LOG_OUT_ERR("MQ_RECEIVE fail\n");
		}
		if (msg_size != 0) {

			// only new valid vehicle signal received can update the vehicle signal variant,
			// otherwise, keep the static variant last value.
		    if ( msg.speed > 0 && msg.speedValid )
		    {
				s_cur_speed = msg.speed;
				//s_cur_speedValid = msg.speedValid;
				s_cur_avas_mode = msg.avas_mode;
				s_cur_gear = msg.gear;
		    }
			else
			{
			    delay(10);
			}
		}
		// wait to update the wav buffer when user change AVAS MODE.
		if ( playState == 0)
			continue;

		outdata = s_msgAvasFmData.avasfmdata;
		if ( outdata == NULL )
			return(NULL);
		
		/* prepare for avas lib */
		param.nCurSpeed = s_cur_speed;
		//0:P,5:D,6:N,7:R,8:M
		switch(s_cur_gear)
		{
			case 0:
			param.nCurGear = 0;
			break;
			case 5:
			param.nCurGear = 4;
			break;
			case 6:
			param.nCurGear = 3;
			break;
			case 7:
			param.nCurGear = 2;
			break;
			case 8:
			param.nCurGear = 4;
			break;
			default:
			param.nCurGear = 0;
		}
		AvasLib_SetParam(&param, &state);
		if(param.nCurSpeed > 30 || (param.nCurGear != 4 && param.nCurGear != 2)
			|| s_cur_avas_mode == AvasServer::MODE_OFF)
			AvasLib_SetWorkState(AVAS_OFF);
		else
			AvasLib_SetWorkState(AVAS_ON);

		debug_info(("speed = %dkm/h, gear = %d\n", param.nCurSpeed, param.nCurGear));
		/* avas data generate to play */
		for(unsigned int i=0; i< AVAS_GENDATA_BUFFSIZE/sizeof(int32_t) / numberofsample; i++)
		{
			if(s_bufLen - s_bufIdx >= numberofsample*sizeof(int32_t))
			{
				memcpy(buffer, (char*)s_buf+s_bufIdx, numberofsample*sizeof(int32_t));
				//buffer = (int32_t *)((char*)s_buf+s_bufIdx);
				s_bufIdx += numberofsample*sizeof(int32_t);
			}
			else
			{
				int len = s_bufLen - s_bufIdx;
				if(len > 0)
					memcpy(buffer, (char*)s_buf+s_bufIdx, len);
				memcpy(buffer + s_bufLen - s_bufIdx, (char*)s_buf, numberofsample*sizeof(int32_t) - len);
				
				s_bufIdx = numberofsample*sizeof(int32_t) - len;
				//buffer = (int32_t *)(char*)s_buf;
			}
			AvasLib_GenData((int32_t *)buffer, (int32_t *)outdata+i*numberofsample);
		}		

		// send avas data to writeData thread
		s_msgAvasFmData.avasgendone = true;
		s_msgAvasFmData.avasfmposition = s_bufIdx;
	    mq_send(g_mqAvasQ, (char *) &s_msgAvasFmData, sizeof(s_msgAvasFmData), 0);
		debug_info(("send avas frame at %d\n", s_msgAvasFmData.avasfmposition));

	}
	if (buffer) free(buffer);
	return NULL;
}


//回调写入播放数据，需要根据实际情况进行逻辑处理
int writeData(int nframes, void *arg, int size)
{
	AVAS_FMDATA_t msgAvasData;
	struct mq_attr mqstat;
    int msg_size;
	
    DataBuf *pBufs = (DataBuf *)arg;
    unsigned int bufSize = nframes * g_block_align;
    unsigned int nChMax = ( g_channels > 2 ? 2 : g_channels );
    char* pDestBuf[nChMax];

	char *outdata = NULL;
	char *pSrcBuffer = NULL;
	unsigned int waitTime = 0;

	static int32_t s_lastest_readIndex = -1;
	bool bGotReadbuf = false;

    playState = 1;
    if(s_bufIdx == 0)
    {
        LOG_OUT_INFO("%s:%d:%d:%d:%d\n",__func__,nframes,size,g_channels,g_block_align);
		debug_info(("%s:%d:%d:%d:%d\n",__func__,nframes,size,g_channels,g_block_align));
    }

	// qnx message queue attributes
	mq_getattr(g_mqAvasQ, &mqstat);

	debug_info(("mqstat.mq_msgsize :%d\n",mqstat.mq_msgsize));
	memset(&msgAvasData, 0, sizeof(AVAS_FMDATA_t));
	msg_size = mq_receive(g_mqAvasQ, (char *) &msgAvasData, (long) &mqstat.mq_msgsize,NULL);
	// check for error
	if (msg_size == -1) {
		LOG_OUT_ERR("MQ_RECEIVE g_mqAvasQ fail\n");
	}
	if (msg_size != 0) {

	    if ( msgAvasData.avasgendone )
	    {
	        s_lastest_readIndex = msgAvasData.avasfmposition;
	        outdata = msgAvasData.avasfmdata;
	        memcpy(s_avasDataLastBackup, outdata, AVAS_GENDATA_BUFFSIZE);
	    
	    }
		else
		{
		    outdata = s_avasDataLastBackup;
			delay(5);
			return 0;
		}
	}

    pSrcBuffer = outdata ? (char*)outdata : s_buf+s_bufIdx;
	
    for(unsigned int ch = 0; ch < nChMax; ch++)
    {
        pDestBuf[ch] = (char*)(pBufs[ch].ioBuf);
    }
	
	for(unsigned int i = 0; i < bufSize; i+=g_block_align)
	{
		for(unsigned int ch = 0; ch < nChMax; ch++)
		{
			*pDestBuf[ch]++ = pSrcBuffer[ch*2+i];
			*pDestBuf[ch]++ = pSrcBuffer[ch*2+i+1];
		}
	}
	if ( DebugLevel > 4 )
	{
		printf("%s: play frame:%d\n", __func__, s_lastest_readIndex);
		printf("%s: play total:%d ===> %d\n", __func__, s_bufLen, s_bufIdx);
	}
    return 0;
	
}

//原始示例 - 回调写入播放数据，需要根据实际情况进行逻辑处理
int writeData_BoschExample(int nframes, void *arg, int size)
{
    DataBuf *pBufs = (DataBuf *)arg;
    unsigned int bufSize = nframes * g_block_align;
    unsigned int nChMax = ( g_channels > 2 ? 2 : g_channels );
    char* pDestBuf[16];
    playState = 1;
    if(s_bufIdx == 0)
    {
        printf ("%s:%d:%d:%d:%d\n",__func__,nframes,size,g_channels,g_block_align);
    }
	PRINT_TIMESTAMP("enter")

    for(unsigned int ch = 0; ch < nChMax; ch++)
    {
        pDestBuf[ch] = (char*)(pBufs[ch].ioBuf);
    }

    if( (s_bufLen - s_bufIdx) >= bufSize )
    {
        for(unsigned int i = 0; i < bufSize; i+=g_block_align)
        {
            for(unsigned int ch = 0; ch < nChMax; ch++)
            {
                *pDestBuf[ch]++ = s_buf[s_bufIdx+ch*2+i];
                *pDestBuf[ch]++ = s_buf[s_bufIdx+ch*2+i+1];
            }
        }
        s_bufIdx += bufSize;
    }
    else
    {
        for(unsigned int i = 0; i < bufSize; i+=g_block_align)
        {
            for(unsigned int ch = 0; ch < nChMax; ch++)
            {
                if( i < s_bufLen - s_bufIdx)
                {
                    *pDestBuf[ch]++ = s_buf[s_bufIdx+ch*2+i];
                    *pDestBuf[ch]++ = s_buf[s_bufIdx+ch*2+i+1];
                }
                else
                {
                    *pDestBuf[ch]++ = 0;
                    *pDestBuf[ch]++ = 0;
                }
            }
        }
        s_bufIdx = s_bufLen;
        playState = 0;
        printf ("%s: play total:%d ===> %d\n", __func__, s_bufLen, s_bufIdx);
        s_bufIdx = 0;
    }
	PRINT_TIMESTAMP("exit")
    return 0;
}


bool external_sound_init(ChimeFileBuffer *chimeFileBuffer)
{
	bool ret = false;
	ret = initExternalSound(external_sound_type_avas);
	if ( !ret ) debug_info(("initExternalSound failed!\n"));
    return (ret);
		
}
void external_sound_destroy()
{
    destroyExternalSound(external_sound_type_avas);
#if 0
	pthread_mutex_destroy(&lastest_read_lock);
	if (s_avasDataPing)
		free(s_avasDataPing);
	if (s_avasDataPong)
		free(s_avasDataPong);
#endif
}

void external_sound_play_bosch_example()
{

	int ret = play((play_type_enum)external_sound_type_avas, writeData_BoschExample);
	debug_info(("play BoschExample ret:%d\n", ret));
	
}


void external_sound_play()
{

	int ret = play((play_type_enum)external_sound_type_avas, writeData);
	debug_info(("play ret:%d\n", ret));
	
}

void external_sound_stop()
{
	int ret = stop(external_sound_type_avas,external_sound_stop_type_immediately);
	debug_info(("stop ret:%d\n", ret));
	
	playState = 0;
}
